import csv, json, sys

def organizeStudentsData(studentsDataList):
    studentsData = {}
    for student in studentsDataList:
        #just in case in csv there is an extra line
        if student == []:
            continue
        studentsData[int(student[0])] = {"name": student[1], "totalAverage":0 , "courses":{}}
    return studentsData

def organizeCourseData(courseDataList):
    courseData = {}
    for course in courseDataList:
        if course == []:
            continue
        courseData[int(course[0])] = {"name":course[1], "teacher":course[2], "totalTestsWeights": []}
    return courseData

def organizeTestData(testsDataList,courseData):
    testsData = {}
    for test in testsDataList:
        if test == []:
            continue
        testsData[int(test[0])] = {"course":int(test[1]), "weight":int(test[2])}
        courseData[int(test[1])]["totalTestsWeights"].append(testsData[int(test[0])]["weight"])
        
        if(sum(courseData[int(test[1])]["totalTestsWeights"]) > 100):
            return -1 
    return testsData

def recordTestsMarks(marksDataList, testsData, studentsData, courseData):
    for marks in marksDataList:
        test_id = int(marks[0])
        student_id = int(marks[1])
        test_mark = int(marks[2])
      
        
        #first get course info and test weight 
        course_id = testsData[test_id]["course"]
        test_weight = testsData[test_id]["weight"]
        course_name = courseData[course_id]["name"]
        course_teacher = courseData[course_id]["teacher"]
        actual_test_value = (test_mark/float(100)) * test_weight
         
        #if there are recorded tests scores for course a student is taking
        #it will record the score in the student object accordingly and update the course average
        course_value = studentsData[student_id]["courses"].get(course_id)
        if course_value:
            currentMarks = studentsData[student_id]["courses"][course_id]["tests"]
            currentMarks.append(actual_test_value)
            
            studentsData[student_id]["courses"][course_id]["tests"] = currentMarks
            studentsData[student_id]["courses"][course_id]["courseAverage"] = round(sum(currentMarks),2)
        #set course value in student data object if needed
        else:
            studentsData[student_id]["courses"][course_id] = {"name":course_name, "teacher":course_teacher, "tests": [actual_test_value],"courseAverage":actual_test_value}
    return studentsData
    
def setTotalAverage(studentsData):
    for student_id in studentsData.keys():
        courses = studentsData[student_id]["courses"]
        sumOfCourseAvg = 0
        for course_id in courses.keys(): 
            sumOfCourseAvg += courses[course_id]["courseAverage"]
        if len(courses)>0:
            studentsData[student_id]["totalAverage"] = round(sumOfCourseAvg/len(courses),2)
    return studentsData



def setFinalObject(studentsData):
    finalObject = {"students" :[]}
    for key,value in studentsData.items():
        currentObject = {}
        
        currentObject["id"] = key 
        currentObject["name"] = value["name"] 
        currentObject["totalAverage"] = value["totalAverage"]
        currentObject["courses"] = []
        
        courses = value["courses"]
        for course_id in courses.keys():
            newCourseObj = courses[course_id]
            newCourseObj["id"] = course_id
            del newCourseObj["tests"]
            currentObject["courses"].append(newCourseObj)
        
        finalObject["students"].append(currentObject)
    
    return finalObject
        
if __name__ == "__main__":
    coursesPath = sys.argv[1]
    studentPath = sys.argv[2]
    testsPath = sys.argv[3]
    marksPath = sys.argv[4]
    outputJson = sys.argv[5]
    
    studentsFile = open(studentPath)
    reader = csv.reader(studentsFile)
    studentsDataList = list(reader)[1:]
    studentsData = organizeStudentsData(studentsDataList)

    courseFile = open(coursesPath)
    reader = csv.reader(courseFile)
    courseDataList = list(reader)[1:]
    courseData = organizeCourseData(courseDataList)


    testsFile = open(testsPath)
    reader = csv.reader(testsFile)
    testsDataList = list(reader)[1:]
    testsData = organizeTestData(testsDataList,courseData)

    if testsData == -1:
        with open(outputJson, 'w') as json_file:
            errorObj = {"error": "Invalid course weights"}
            json.dump(errorObj, json_file)
        

    else:
        marksFile = open(marksPath)
        reader = csv.reader(marksFile)
        marksDataList = list(reader)[1:] 
        if marksDataList[-1] == []:
            marksDataList = marksDataList[1:-1]


            

        recordTestsMarks(marksDataList, testsData, studentsData, courseData)
        setTotalAverage(studentsData)
        finalObj = setFinalObject(studentsData)
        finalObj["students"] = sorted(finalObj["students"], key = lambda student: student['id'])

        with open('output.json', 'w') as json_file:
            json.dump(finalObj, json_file)